const port = 3000;
const path = require('path');
const express = require('express');
const morgan = require('morgan');

const app = express();
app.use(morgan('tiny'));
app.set('views', './views');
app.set('view engine', 'ejs');
app.listen(port, () => {
  console.log(`server is listening on port ${port}`);
  });

app.use('/css', express.static(path.join(__dirname, '/public/css')));

app.get('/', (req, resp) => {
    resp.sendFile(path.join(__dirname, 'public', 'index.html'));
})

app.use('/pilots', require('./routes/pilot-router'));