const express = require('express');
const pilotRouter = express.Router();
const dataService = require('../services/pilot-data.service');

function renderPilots(err, data, resp) {
    if (err) {
        console.error(err);
        resp.sendStatus(500);
    } else {
        resp.render('pilots', { pilots: data });
    }
}

function toPromise(fn, ...params) {
    return new Promise((res, rej) => {
        fn(...params, (err, data) => {
            if (err) {
                rej(err)
            } else {
                res(data);
            }
        });
    });
}

pilotRouter.route('/').get((req, resp) => {
    let selectedLevel = req.query.level;
    if(!selectedLevel) {
      selectedLevel = "";
    }
    
    const promises = [
        toPromise(dataService.getRobots)
    ];
    Promise.all(promises)
        .then(([robots]) => {
            robots.map(x => x.rank = addRank(x.flight_hours))
            resp.render('pilots', { robots, selectedLevel })
        })
        .catch(err => {
            resp.status(500);
            console.error(err);
        });
});

function addRank(level) {  
    if (level < 1000) return "junior";
    if (level > 1000 && level < 5000) return "medior";
    if (level > 5000) return "senior";
    return "";
}

pilotRouter.route('/:id').get((req, resp) => {    
    let robotId = req.params.id;
    const promises = [
        toPromise(dataService.getRobotById, robotId),
        toPromise(dataService.getPilots),
        toPromise(dataService.getSpaceships)
    ];
    Promise.all(promises)
        .then(([robot, pilots, ships]) => {
            let myShipIds = Array.from(pilots.filter(p => p.robot == robot.id)).map(x => x.spaceship);            
            robot.ships = ships.filter(s => myShipIds.includes(s.id));
            resp.render('pilot', { robot })
        })
        .catch(err => {
            resp.status(500);
            console.error(err);
        });
});

module.exports = pilotRouter;