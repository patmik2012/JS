const express = require('express');
const morgan = require('morgan');


const app = express();
app.use(morgan('dev'));
const port = 3000;
const path = require('path');


app.set('views', './views');
app.set('view engine', 'ejs');

app.use('/css', express.static(path.join(__dirname, 'public/css')));

app.use('/css',
  express.static('/node_modules/bootstrap/dist/css'));

app.use('/js',
  express.static(path.join(__dirname, '/node_modules/jquery/dist')));

app.get('/', (req, resp) => {
    resp.sendFile(path.join(__dirname, 'public', 'index.html'));
})


app.use('/people', require(path.join(__dirname,'routes/people-router.js')));
app.use('/planet', require(path.join(__dirname,'routes/planet-router.js')));



app.listen(port, () => {
    console.log(`server is listening on port ${port}`);
});
