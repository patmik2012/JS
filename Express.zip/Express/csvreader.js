const fs = require('fs');
const csv = require('csv-parser');

const peopleData = [];
const planetData = [];
const residentsData = [];

function init() {
  fs.createReadStream('data/csv/people.csv')
    .pipe(csv()).on('data', (data) => peopleData.push(data));
  fs.createReadStream('data/csv/planets.csv')
    .pipe(csv()).on('data', (data) => planetData.push(data));
  fs.createReadStream('data/csv/residents.csv')
    .pipe(csv()).on('data', (data) => residentsData.push(data));
}

function findById(data, id) {
  return data.filter(d => d.id === id)[0];
}

function getPeople() {
  console.log("getPeople");
  return peopleData;
}

function getPersonData(id) {
  return findById(peopleData, id);
}

function getAllPlanetData() {
  return planetData;
}

function getOnePlanetData(id) {
  return findById(planetData,id);
}

function getAllPopulation(id) {
  return residentsData.filter(resident => resident.planet === id)
    .map(element => element.planet).map(idpeople => findById(peopleData, idpeople));
}

function deletePerson(id) {
  delete peopleData.filter(person => person.id === id);
}
module.exports = {
  init,
  getPeople,
  getPersonData,
  getAllPlanetData,
  getOnePlanetData,
  getAllPopulation,
  deletePerson,
}