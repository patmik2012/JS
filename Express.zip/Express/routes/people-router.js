const express = require('express');
const morgan = require('morgan');
const peopleRouter = express.Router();
const csv = require('../csvreader.js');
const ejs = require('ejs');

peopleRouter.route('/').get(async (req, res, next) => {
  const planet = req.query.planet;
  if (planet) {
    try {
      const people = await csv.getPeople();
      const residents = await csv.getResidents(planet);
      res.render('people' , { people : people.filter(p => residents.includes(p.id)) });
    } catch (e) {
      next(e) 
    }
  }
  else {
    try {
      const people = await csv.getPeople();
      res.render('people' , { people : people });
    } catch (e) {
      next(e) 
    }
  }
})


peopleRouter.route('/:id').get(async (req, res, next) => {
  try {
    const person = await csv.getPersonById(req.params.id)
    res.render('person' , { person : person });
  } catch (e) {
    next(e) 
  }
})



module.exports = peopleRouter;