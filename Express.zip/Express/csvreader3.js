var fs = require('fs'); 
const path = './data/csv/'
const csv = require('csvtojson')

let getAllPeopleData = () => {
  return new Promise((resolve, reject) => {
    csv().fromFile(path + '/people.csv').then(jsonData => resolve(jsonData)).catch(err => reject(err))
  })
}

let getAllPlanetData = () => {
  return new Promise((resolve, reject) => {
    csv().fromFile(path + '/planets.csv').then(jsonData => resolve(jsonData)).catch(err => reject(err))
  })
}

let getPersonDataById = (personID) => {
  return new Promise((resolve, reject) => {
    csv().fromFile(path + '/people.csv').then(jsonData => {

      jsonData.forEach(person => {
        if(person.id == personID){
          resolve(person)
        }
      })
    }).catch(err => reject(err))
  })
}

let getPlanetDataById = (planetID) => {
  return new Promise((resolve, reject) => {
    csv().fromFile(path + '/planets.csv').then(jsonData => {

      jsonData.forEach(person => {
        if(person.id == planetID){
          resolve(person)
        }
      })
    }).catch(err => reject(err))
  })
}

module.exports.getAllPeopleData = getAllPeopleData;
module.exports.getAllPlanetData = getAllPlanetData;
module.exports.getPersonDataById = getPersonDataById;
module.exports.getPlanetDataById = getPlanetDataById;