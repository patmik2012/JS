const path = require('path');
const fs = require('fs');
const neatCsv = require('neat-csv');
const objectsToCsv = require('objects-to-csv');

const personFile = path.join(__dirname, '/data/csv/people.csv');
const planetFile = path.join(__dirname, '/data/csv/planets.csv');
const residentFile = path.join(__dirname, '/data/csv/residents.csv');

class Person {
  id;
  name;
  height;
  mass;
  skin_color;
  hair_color;
  birth_year;
  gender;

  constructor(obj){
    Object.assign(this, obj)
  }

  get id() { return this.id; }
  get name() { return this.name; }
  get height() { return this.height; }
  get mass() { return this.mass; }
  get skin_color() { return this.skin_color; }
  get hair_color() { return this.hair_color; }
  get birth_year() { return this.birth_year; }
  get gender() { return this.gender; }

} 

class Planet {
  id;
  name;
  climate;
  diameter;

  constructor(obj){
    Object.assign(this, obj)
  }  

  get id() { return this.id; }
  get name() { return this.name; }
  get climate() { return this.climate; }
  get diameter() { return this.diameter; }

}

class Resident {
  resident;
  planet;  

  constructor(obj){
    Object.assign(this, obj)
  }

  get resident() { return this.resident; }
  get planet() { return this.planet; }

}

const getPeople = () => {
  return new Promise((resolve, reject) => { 
    fs.readFile(personFile, async (err, data) => {
      if (err) {
        reject(err);
        return }
      let csvObj = await neatCsv(data);
      let results = [];
      csvObj.forEach(x => results.push(new Person(x)));
      resolve(results);
    });
  });
};

const getPersonById = (id) => {
  return new Promise((resolve, reject) => { 
    fs.readFile(personFile, async (err, data) => {
      if (err) {
        reject(err);
        return }
      let csvObj = await neatCsv(data);
      let results = [];
      csvObj.forEach(x => results.push(new Person(x)));
      resolve(results[id-1]);
    });
  });
};

const getPlanets = () => {
  return new Promise((resolve, reject) => { 
    fs.readFile(planetFile, async (err, data) => {
      if (err) {
        reject(err);
        return }
      let csvObj = await neatCsv(data);
      let results = [];
      csvObj.forEach(x => results.push(new Planet(x)));
      resolve(results);
    });
  });
};

const getPlanetById = (id) => {
  return new Promise((resolve, reject) => { 
    fs.readFile(planetFile, async (err, data) => {
      if (err) {
        reject(err);
        return }
      let csvObj = await neatCsv(data);
      let results = [];
      csvObj.forEach(x => results.push(new Planet(x)));
      resolve(results[id-1]);
    });
  });
};

const getResidents = (id) => {
  return new Promise((resolve, reject) => { 
    fs.readFile(residentFile, async (err, data) => {
      if (err) {
        reject(err);
        return }
      let csvObj = await neatCsv(data);
      let results = [];
      csvObj.forEach(x => results.push(new Resident(x)));
      resolve(results.filter(x => x.planet == id).map(x => x.resident));
    });
  });
};

module.exports = {
  getPeople,
  getPersonById,
  getPlanets,
  getPlanetById,
  getResidents
};